/* eslint-disable import/no-anonymous-default-export */
import { AUTH, LOGOUT } from '../constants/actionTypes';

const authReducer = (state={ authData: null }, action) => {
  switch (action.type) {
    case AUTH:
      localStorage.setItem('profile', JSON.stringify({ ...action?.data }))
      return { ...state, authData: action.data };
    case LOGOUT:
      localStorage.clear();
      return { ...state, authData: null };
    default:
      return { ...state, authData: action.data };
  }
};


export default authReducer;